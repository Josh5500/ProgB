let hKnap
let mKnap
let sKnap

//function preload(){
    //let a = loadSound('assets/520765__ofresco__sans.mp3');
    
//}




